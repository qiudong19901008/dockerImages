<?php
declare (strict_types=1);

return [
    'version' => '0.7.3-beta',
];