<?php
declare(strict_types=1);

namespace App\Consts;


interface Shared
{
    /**
     * SESSION会话名称
     */
    const SESSION = "SHARED_USER";
}