<?php
declare (strict_types=1);

return [
    [
        "title" => "DEMO",
        "name" => "demo",
        "type" => "input",
        "placeholder" => "DEMO配置"
    ]
];